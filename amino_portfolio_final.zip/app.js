console.log("App initialized");

const adminUser = {
  username: "amino53446",
  pin: "amino2010"
};

function login(username, pin) {
  console.log("Attempting login with:", username);
  if (username === adminUser.username && pin === adminUser.pin) {
    console.log("Login successful");
    // Show admin panel
  } else {
    console.warn("Login failed");
  }
}
